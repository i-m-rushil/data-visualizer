# Data-Visualizer
Technologies used: Python, Django (Python web framework), HTML, CSS, Bootstrap, pandas, Matplotlib

It is a data visualization platform which takes .csv file as input, extract the column names, prepares scatter plot of column values selected by the user.
