from django.apps import AppConfig


class DatavisualizerConfig(AppConfig):
    name = 'DataVisualizer'
